package com.sorprendeme.backend.controller;

import com.sorprendeme.backend.model.Usuario;
import com.sorprendeme.backend.service.UsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

/**
 * Controlador REST para el recurso Usuario.
 * Expone los endpoints de registro, login y consulta de usuarios.
 */
@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /**
     * POST /api/usuarios/registro
     * Recibe: { nombre, email, password }
     * Coincide exactamente con el formulario de registro del frontend.
     * Retorna el usuario creado con su id asignado por la BD.
     */
    @PostMapping("/registro")
    public ResponseEntity<Usuario> registrar(@RequestBody Usuario usuario) {
        Usuario nuevo = usuarioService.registrar(usuario);
        return ResponseEntity.ok(nuevo);
    }

    /**
     * POST /api/usuarios/login
     * Recibe: { email, password }
     * Retorna el usuario si las credenciales son correctas.
     * En un proyecto real esto devolveria un token JWT.
     */
    @PostMapping("/login")
    public ResponseEntity<Usuario> login(@RequestBody Map<String, String> credenciales) {
        String email = credenciales.get("email");
        String password = credenciales.get("password");
        Usuario usuario = usuarioService.login(email, password);
        return ResponseEntity.ok(usuario);
    }

    /**
     * GET /api/usuarios
     * Retorna todos los usuarios registrados.
     * Usado en el panel de administracion para ver quienes se han registrado.
     */
    @GetMapping
    public List<Usuario> obtenerTodos() {
        return usuarioService.obtenerTodos();
    }
}
