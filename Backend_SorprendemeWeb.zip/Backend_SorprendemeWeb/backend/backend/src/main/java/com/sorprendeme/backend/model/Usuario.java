package com.sorprendeme.backend.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * Entidad que representa un usuario registrado en la tienda.
 * Coincide exactamente con el formulario de registro del frontend:
 * nombre, email, password.
 *
 * La password NO se guarda en texto plano en un proyecto real,
 * pero para este nivel academico la guardamos directamente.
 */
@Data
@Entity
@Table(name = "usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre completo del usuario (campo "Nombre completo" del formulario)
    @Column(nullable = false, length = 100)
    private String nombre;

    // Email unico — no pueden existir dos usuarios con el mismo correo
    @Column(nullable = false, unique = true, length = 100)
    private String email;

    // Contrasena del usuario (campo "Contrasena" del formulario)
    @Column(nullable = false, length = 255)
    private String password;

    // Fecha en que se registro — se asigna automaticamente
    @Column(nullable = false)
    private LocalDateTime fechaRegistro = LocalDateTime.now();

    // El usuario esta activo por defecto al registrarse
    private boolean activo = true;
}
