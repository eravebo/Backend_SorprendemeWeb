package com.sorprendeme.backend.service;

import com.sorprendeme.backend.model.Usuario;
import com.sorprendeme.backend.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Servicio de Usuario.
 * Contiene la logica de negocio para registro e inicio de sesion.
 */
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Registra un usuario nuevo.
     * Verifica que el email no este ya registrado antes de guardar.
     * Coincide con el formulario de registro del frontend:
     * nombre + email + password.
     */
    public Usuario registrar(Usuario usuario) {
        try {
            // Verificamos que el email no este ya en uso
            if (usuarioRepository.existsByEmail(usuario.getEmail())) {
                throw new RuntimeException("El correo ya esta registrado");
            }
            return usuarioRepository.save(usuario);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Error al registrar el usuario: " + e.getMessage());
        }
    }

    /**
     * Inicia sesion de un usuario.
     * Busca por email y password — si no existe lanza excepcion.
     */
    public Usuario login(String email, String password) {
        try {
            return usuarioRepository.findByEmailAndPassword(email, password)
                    .orElseThrow(() -> new RuntimeException("Correo o contrasena incorrectos"));
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Error al iniciar sesion: " + e.getMessage());
        }
    }

    /**
     * Retorna todos los usuarios registrados.
     * Usado en el panel de administracion.
     */
    public List<Usuario> obtenerTodos() {
        try {
            return usuarioRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error al obtener los usuarios: " + e.getMessage());
        }
    }
}
