package com.sorprendeme.backend.repository;

import com.sorprendeme.backend.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

/**
 * Repositorio de Usuario.
 * Spring genera automaticamente el SQL de cada metodo por su nombre.
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Busca usuario por email — usado para verificar si ya existe al registrarse
    // Spring traduce: WHERE email = ?
    Optional<Usuario> findByEmail(String email);

    // Busca usuario por email Y password — usado para el login
    // Spring traduce: WHERE email = ? AND password = ?
    Optional<Usuario> findByEmailAndPassword(String email, String password);

    // Verifica si ya existe un usuario con ese email
    // Spring traduce: SELECT COUNT(*) > 0 WHERE email = ?
    boolean existsByEmail(String email);
}
