package com.sorprendeme.backend.service;

import com.sorprendeme.backend.model.Producto;
import com.sorprendeme.backend.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Prueba UNITARIA de ProductoService.
 *
 * Concepto clave: estas pruebas NO tocan la base de datos real.
 * Mockito crea un "doble" del repositorio que simula su comportamiento.
 * Asi podemos probar la logica del servicio de forma aislada y rapida.
 *
 * @ExtendWith(MockitoExtension.class) — activa Mockito en JUnit 5
 * @Mock — crea el objeto simulado del repositorio
 * @InjectMocks — crea el servicio e inyecta el mock automaticamente
 */
@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    private Producto producto;

    /**
     * @BeforeEach se ejecuta ANTES de cada test.
     * Prepara los datos de prueba para no repetir codigo.
     */
    @BeforeEach
    void setUp() {
        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Ancheta Romantica");
        producto.setDescripcion("Chocolates artesanales y vino rosado");
        producto.setPrecio(85000.0);
        producto.setCategoria("ancheta");
        producto.setImagenUrl("../img/Ancheta_1.jpeg");
        producto.setStock(10);
        producto.setActivo(true);
    }

    /**
     * Test 1: obtenerTodos debe retornar la lista de productos activos.
     * Patron AAA: Arrange (preparar) -> Act (ejecutar) -> Assert (verificar)
     */
    @Test
    void obtenerTodos_deberiaRetornarListaDeProductosActivos() {
        // ARRANGE: le decimos al mock que cuando se llame findByActivoTrue
        // devuelva nuestra lista de prueba
        when(productoRepository.findByActivoTrue())
                .thenReturn(Arrays.asList(producto));

        // ACT: ejecutamos el metodo que queremos probar
        List<Producto> resultado = productoService.obtenerTodos();

        // ASSERT: verificamos que el resultado es correcto
        assertNotNull(resultado, "La lista no debe ser nula");
        assertEquals(1, resultado.size(), "Debe haber exactamente 1 producto");
        assertEquals("Ancheta Romantica", resultado.get(0).getNombre());
        assertTrue(resultado.get(0).isActivo(), "El producto debe estar activo");

        // Verificamos que el repositorio fue llamado exactamente 1 vez
        verify(productoRepository, times(1)).findByActivoTrue();
    }

    /**
     * Test 2: obtenerPorCategoria debe filtrar correctamente por categoria.
     */
    @Test
    void obtenerPorCategoria_deberiaRetornarProductosDeLaCategoria() {
        // ARRANGE
        when(productoRepository.findByCategoriaAndActivoTrue("ancheta"))
                .thenReturn(Arrays.asList(producto));

        // ACT
        List<Producto> resultado = productoService.obtenerPorCategoria("ancheta");

        // ASSERT
        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("ancheta", resultado.get(0).getCategoria());
        verify(productoRepository, times(1)).findByCategoriaAndActivoTrue("ancheta");
    }

    /**
     * Test 3: guardar debe retornar el producto guardado.
     */
    @Test
    void guardar_deberiaRetornarProductoGuardado() {
        // ARRANGE
        when(productoRepository.save(producto)).thenReturn(producto);

        // ACT
        Producto resultado = productoService.guardar(producto);

        // ASSERT
        assertNotNull(resultado);
        assertEquals("Ancheta Romantica", resultado.getNombre());
        assertEquals(85000.0, resultado.getPrecio());
        verify(productoRepository, times(1)).save(producto);
    }

    /**
     * Test 4: desactivar debe marcar el producto como inactivo (borrado logico).
     */
    @Test
    void desactivar_cuandoProductoExiste_deberiaMarcarloComoInactivo() {
        // ARRANGE
        when(productoRepository.findById(1L))
                .thenReturn(Optional.of(producto));

        // ACT
        productoService.desactivar(1L);

        // ASSERT: el producto debe quedar con activo = false
        assertFalse(producto.isActivo(), "El producto debe quedar inactivo");
        // Verificamos que se guardo el cambio en la BD
        verify(productoRepository, times(1)).save(producto);
    }

    /**
     * Test 5: desactivar con id inexistente debe lanzar RuntimeException.
     * Probamos que el manejo de errores funciona correctamente.
     */
    @Test
    void desactivar_cuandoProductoNoExiste_deberiaLanzarExcepcion() {
        // ARRANGE: el repositorio devuelve vacio para el id 99
        when(productoRepository.findById(99L))
                .thenReturn(Optional.empty());

        // ASSERT: verificamos que lanza la excepcion correcta
        RuntimeException excepcion = assertThrows(RuntimeException.class, () -> {
            productoService.desactivar(99L);
        });

        // Verificamos que el mensaje de error es descriptivo
        assertTrue(excepcion.getMessage().contains("99"),
                "El mensaje debe incluir el id que no se encontro");
    }
}
