package com.sorprendeme.backend.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorprendeme.backend.model.Producto;
import com.sorprendeme.backend.service.ProductoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Prueba de INTEGRACION del ProductoController.
 *
 * @WebMvcTest carga solo la capa web (Controller) sin levantar
 * el servidor completo ni conectarse a la base de datos.
 * MockMvc simula peticiones HTTP reales al endpoint.
 *
 * Diferencia con las pruebas unitarias:
 * - Prueba unitaria: verifica la logica de una clase aislada
 * - Prueba de integracion: verifica que las capas funcionan juntas
 *   (HTTP -> Controller -> Service -> respuesta JSON)
 */
@WebMvcTest(ProductoController.class)
class ProductoControllerTest {

    // MockMvc simula peticiones HTTP sin necesitar un servidor real
    @Autowired
    private MockMvc mockMvc;

    // MockBean reemplaza el ProductoService real por uno simulado
    @MockBean
    private ProductoService productoService;

    // ObjectMapper convierte objetos Java a JSON y viceversa
    @Autowired
    private ObjectMapper objectMapper;

    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Ancheta Romantica");
        producto.setDescripcion("Chocolates artesanales y vino rosado");
        producto.setPrecio(85000.0);
        producto.setCategoria("ancheta");
        producto.setImagenUrl("../img/Ancheta_1.jpeg");
        producto.setStock(10);
        producto.setActivo(true);
    }

    /**
     * Test 1: GET /api/productos debe retornar 200 OK con lista de productos.
     */
    @Test
    void getProductos_deberiaRetornar200ConListaDeProductos() throws Exception {
        // ARRANGE
        when(productoService.obtenerTodos()).thenReturn(Arrays.asList(producto));

        // ACT + ASSERT
        mockMvc.perform(get("/api/productos"))
                .andExpect(status().isOk())
                // jsonPath verifica campos especificos del JSON de respuesta
                .andExpect(jsonPath("$[0].nombre").value("Ancheta Romantica"))
                .andExpect(jsonPath("$[0].precio").value(85000.0))
                .andExpect(jsonPath("$[0].categoria").value("ancheta"));
    }

    /**
     * Test 2: GET /api/productos?categoria=ancheta debe filtrar por categoria.
     */
    @Test
    void getProductosPorCategoria_deberiaRetornarProductosFiltrados() throws Exception {
        // ARRANGE
        when(productoService.obtenerPorCategoria("ancheta"))
                .thenReturn(Arrays.asList(producto));

        // ACT + ASSERT
        mockMvc.perform(get("/api/productos").param("categoria", "ancheta"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].categoria").value("ancheta"));
    }

    /**
     * Test 3: POST /api/productos debe crear el producto y retornar 200.
     */
    @Test
    void postProducto_deberiaCrearProductoYRetornar200() throws Exception {
        // ARRANGE
        when(productoService.guardar(any(Producto.class))).thenReturn(producto);

        // ACT + ASSERT
        // Convertimos el objeto a JSON para enviarlo en el body
        mockMvc.perform(post("/api/productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(producto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Ancheta Romantica"))
                .andExpect(jsonPath("$.id").value(1));
    }

    /**
     * Test 4: DELETE /api/productos/{id} debe retornar 204 No Content.
     */
    @Test
    void deleteProducto_deberiaRetornar204SinContenido() throws Exception {
        // ARRANGE: desactivar no retorna nada (void)
        doNothing().when(productoService).desactivar(1L);

        // ACT + ASSERT
        mockMvc.perform(delete("/api/productos/1"))
                .andExpect(status().isNoContent());

        verify(productoService, times(1)).desactivar(1L);
    }
}
