package com.sorprendeme.backend.service;

import com.sorprendeme.backend.model.Pedido;
import com.sorprendeme.backend.repository.PedidoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Prueba UNITARIA de PedidoService.
 * Verifica que la logica de negocio de pedidos funciona correctamente
 * sin necesitar la base de datos real.
 */
@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {

    @Mock
    private PedidoRepository pedidoRepository;

    @InjectMocks
    private PedidoService pedidoService;

    private Pedido pedido;

    @BeforeEach
    void setUp() {
        pedido = new Pedido();
        pedido.setId(1L);
        pedido.setNombreCliente("Maria Garcia");
        pedido.setEmail("maria@gmail.com");
        pedido.setTelefono("3001234567");
        pedido.setDireccionEnvio("Calle 123, Medellin");
        pedido.setEstado("pendiente");
    }

    /**
     * Test 1: crearPedido debe guardar y retornar el pedido con sus datos.
     */
    @Test
    void crearPedido_deberiaGuardarYRetornarPedidoConDatosCorrectos() {
        // ARRANGE
        when(pedidoRepository.save(any(Pedido.class))).thenReturn(pedido);

        // ACT
        Pedido resultado = pedidoService.crearPedido(pedido);

        // ASSERT
        assertNotNull(resultado, "El pedido guardado no debe ser nulo");
        assertEquals("Maria Garcia", resultado.getNombreCliente());
        assertEquals("maria@gmail.com", resultado.getEmail());
        assertEquals("pendiente", resultado.getEstado(), "El estado inicial debe ser pendiente");
        verify(pedidoRepository, times(1)).save(pedido);
    }

    /**
     * Test 2: obtenerTodos debe retornar todos los pedidos.
     */
    @Test
    void obtenerTodos_deberiaRetornarListaCompletaDePedidos() {
        // ARRANGE
        Pedido pedido2 = new Pedido();
        pedido2.setId(2L);
        pedido2.setNombreCliente("Carlos Lopez");
        pedido2.setEstado("pagado");

        when(pedidoRepository.findAll()).thenReturn(Arrays.asList(pedido, pedido2));

        // ACT
        List<Pedido> resultado = pedidoService.obtenerTodos();

        // ASSERT
        assertNotNull(resultado);
        assertEquals(2, resultado.size(), "Debe retornar exactamente 2 pedidos");
        verify(pedidoRepository, times(1)).findAll();
    }

    /**
     * Test 3: cambiarEstado debe actualizar el estado del pedido correctamente.
     */
    @Test
    void cambiarEstado_cuandoPedidoExiste_deberiaActualizarEstado() {
        // ARRANGE
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(pedido));
        when(pedidoRepository.save(any(Pedido.class))).thenReturn(pedido);

        // ACT
        Pedido resultado = pedidoService.cambiarEstado(1L, "pagado");

        // ASSERT
        assertEquals("pagado", resultado.getEstado(),
                "El estado debe cambiar de pendiente a pagado");
        verify(pedidoRepository, times(1)).save(pedido);
    }

    /**
     * Test 4: cambiarEstado con flujo completo de estados.
     * Verifica que se puede avanzar por todos los estados del pedido.
     */
    @Test
    void cambiarEstado_deberiaPermitirFlujoCompletoDeEstados() {
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(pedido));
        when(pedidoRepository.save(any(Pedido.class))).thenReturn(pedido);

        // pendiente -> pagado
        pedidoService.cambiarEstado(1L, "pagado");
        assertEquals("pagado", pedido.getEstado());

        // pagado -> enviado
        pedidoService.cambiarEstado(1L, "enviado");
        assertEquals("enviado", pedido.getEstado());

        // enviado -> entregado
        pedidoService.cambiarEstado(1L, "entregado");
        assertEquals("entregado", pedido.getEstado());
    }

    /**
     * Test 5: cambiarEstado con id inexistente debe lanzar excepcion.
     */
    @Test
    void cambiarEstado_cuandoPedidoNoExiste_deberiaLanzarExcepcion() {
        // ARRANGE
        when(pedidoRepository.findById(99L)).thenReturn(Optional.empty());

        // ASSERT
        RuntimeException excepcion = assertThrows(RuntimeException.class, () -> {
            pedidoService.cambiarEstado(99L, "pagado");
        });

        assertTrue(excepcion.getMessage().contains("99"),
                "El mensaje debe indicar el id que no se encontro");
        // Verificamos que NO se intento guardar nada
        verify(pedidoRepository, never()).save(any());
    }
}
