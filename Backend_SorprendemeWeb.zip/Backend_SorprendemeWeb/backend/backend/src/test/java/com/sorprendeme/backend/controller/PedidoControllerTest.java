package com.sorprendeme.backend.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorprendeme.backend.model.Pedido;
import com.sorprendeme.backend.service.PedidoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Prueba de INTEGRACION del PedidoController.
 * Verifica que los endpoints de pedidos responden correctamente.
 */
@WebMvcTest(PedidoController.class)
class PedidoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PedidoService pedidoService;

    @Autowired
    private ObjectMapper objectMapper;

    private Pedido pedido;

    @BeforeEach
    void setUp() {
        pedido = new Pedido();
        pedido.setId(1L);
        pedido.setNombreCliente("Maria Garcia");
        pedido.setEmail("maria@gmail.com");
        pedido.setTelefono("3001234567");
        pedido.setDireccionEnvio("Calle 123, Medellin");
        pedido.setEstado("pendiente");
    }

    /**
     * Test 1: POST /api/pedidos debe crear el pedido y retornar 200.
     */
    @Test
    void postPedido_deberiaCrearPedidoYRetornar200() throws Exception {
        // ARRANGE
        when(pedidoService.crearPedido(any(Pedido.class))).thenReturn(pedido);

        // ACT + ASSERT
        mockMvc.perform(post("/api/pedidos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreCliente").value("Maria Garcia"))
                .andExpect(jsonPath("$.estado").value("pendiente"));
    }

    /**
     * Test 2: GET /api/pedidos debe retornar 200 con lista de pedidos.
     */
    @Test
    void getPedidos_deberiaRetornar200ConListaDePedidos() throws Exception {
        // ARRANGE
        when(pedidoService.obtenerTodos()).thenReturn(Arrays.asList(pedido));

        // ACT + ASSERT
        mockMvc.perform(get("/api/pedidos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombreCliente").value("Maria Garcia"))
                .andExpect(jsonPath("$[0].estado").value("pendiente"));
    }

    /**
     * Test 3: PATCH /api/pedidos/{id}/estado debe actualizar el estado y retornar 200.
     */
    @Test
    void patchEstado_deberiaActualizarEstadoYRetornar200() throws Exception {
        // ARRANGE: simulamos que el pedido cambia a "pagado"
        pedido.setEstado("pagado");
        when(pedidoService.cambiarEstado(eq(1L), eq("pagado"))).thenReturn(pedido);

        // ACT + ASSERT
        mockMvc.perform(patch("/api/pedidos/1/estado")
                        .param("estado", "pagado"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("pagado"));
    }
}
