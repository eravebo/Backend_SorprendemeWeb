package com.sorprendeme.backend.service;

import com.sorprendeme.backend.model.Usuario;
import com.sorprendeme.backend.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Maria Garcia");
        usuario.setEmail("maria@gmail.com");
        usuario.setPassword("123456");
        usuario.setActivo(true);
    }

    @Test
    void registrar_cuandoEmailNuevo_deberiaGuardarUsuario() {
        when(usuarioRepository.existsByEmail("maria@gmail.com")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        Usuario resultado = usuarioService.registrar(usuario);

        assertNotNull(resultado);
        assertEquals("Maria Garcia", resultado.getNombre());
        assertEquals("maria@gmail.com", resultado.getEmail());
        verify(usuarioRepository, times(1)).save(usuario);
    }

    @Test
    void registrar_cuandoEmailYaExiste_deberiaLanzarExcepcion() {
        when(usuarioRepository.existsByEmail("maria@gmail.com")).thenReturn(true);

        RuntimeException excepcion = assertThrows(RuntimeException.class, () -> {
            usuarioService.registrar(usuario);
        });

        assertTrue(excepcion.getMessage().contains("ya esta registrado"));
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void login_cuandoCredencialesCorrectas_deberiaRetornarUsuario() {
        when(usuarioRepository.findByEmailAndPassword("maria@gmail.com", "123456"))
                .thenReturn(Optional.of(usuario));

        Usuario resultado = usuarioService.login("maria@gmail.com", "123456");

        assertNotNull(resultado);
        assertEquals("Maria Garcia", resultado.getNombre());
    }

    @Test
    void login_cuandoCredencialesIncorrectas_deberiaLanzarExcepcion() {
        when(usuarioRepository.findByEmailAndPassword("maria@gmail.com", "wrongpass"))
                .thenReturn(Optional.empty());

        RuntimeException excepcion = assertThrows(RuntimeException.class, () -> {
            usuarioService.login("maria@gmail.com", "wrongpass");
        });

        assertTrue(excepcion.getMessage().contains("incorrectos"));
    }
}
